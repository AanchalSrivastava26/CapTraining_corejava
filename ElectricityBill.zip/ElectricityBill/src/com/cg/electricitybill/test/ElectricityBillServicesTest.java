package com.cg.electricitybill.test;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.electricitybill.beans.Address;
import com.cg.electricitybill.beans.Bill;
import com.cg.electricitybill.beans.Customer;
import com.cg.electricitybill.beans.Meter;
import com.cg.electricitybill.exceptions.CustomerDetailsNotFoundException;
import com.cg.electricitybill.util.ElectricityBillUtil;


import cm.cg.electricitybill.services.ElectricityBillServices;
import cm.cg.electricitybill.services.ElectricityBillServicesImpl;

public class ElectricityBillServicesTest {
	static ElectricityBillServices electricityBillServices;
	@BeforeClass
	public static void setUpTestEnv() {
		electricityBillServices=new ElectricityBillServicesImpl();
	
	}
	@Before
	public void setUpTestData() {
		Customer customer1=new Customer(101,245252652, "aanchal", "srivastava", "jyup1234", "aanchal@gmail.com", 
				new Address(262522,102, "lucknow"), new Meter(123, 560, 1, "one",new Bill(1234, 31, "1325fgsv", "december")));
		Customer customer2=new Customer(102,2425625, "prachi", "srivastava", "jyup7484", "prachi@gmail.com", 
				new Address(27627,103, "lucknow"), new Meter(124, 560, 1, "one",new Bill(1222, 31, "1325fgfdjk", "december")));
		
		ElectricityBillUtil.customers.put(customer1.getCustomerNo(), customer1);
		ElectricityBillUtil.customers.put(customer2.getCustomerNo(), customer2);
	ElectricityBillUtil.CUSTOMER_NO_COUNTER=103;
		
	}
	@Test
	public void testAcceptCustomerDetailsForValidData() {
		int expectedCustomerN0=103;
		int actualCustomerNo=electricityBillServices.acceptCustomerDetails(101,245252652, "aanchal", "srivastava", "jyup1234", "aanchal@gmail.com", 
				new Address(262522,102, "lucknow"), new Meter(123, 560, 1, "one",new Bill(1234, 31, "1325fgsv", "december")));
		Assert.assertEquals(expectedCustomerN0, actualCustomerNo);
	}
@Test(expected=CustomerDetailsNotFoundException.class)
public void testGetCustomerDataForInvalidCustomerNo() throws CustomerDetailsNotFoundException{
 electricityBillServices.getCustomerDetails(262);
}
@Test
public void testGetCustomerDataForValidCustomer() throws CustomerDetailsNotFoundException{
	Customer expectedCustomer=new Customer(101,245252652, "aanchal", "srivastava", "jyup1234", "aanchal@gmail.com", 
			new Address(262522,102, "lucknow"), new Meter(123, 560, 1, "one",new Bill(1234, 31, "1325fgsv", "december")));
	Customer actualCustomer=electricityBillServices.getCustomerDetails(101);
	Assert.assertEquals(expectedCustomer, actualCustomer);
	
}
@Test(expected=CustomerDetailsNotFoundException.class)
public void testCalculateBillForInvalidAssociateId() throws CustomerDetailsNotFoundException{
	electricityBillServices.getCustomerDetails(242);
}
@Test
public void testCalculateBillForValidAssociateId() throws CustomerDetailsNotFoundException{
double expectedBill=7820.0;
double actualBill=electricityBillServices.calculateBill(101);
Assert.assertEquals(expectedBill,actualBill,1000);
}

@Test
public void testForGetAllCustomerDetails() {
	ArrayList<Customer> expectedCustomerList=new ArrayList<>(ElectricityBillUtil.customers.values());
	ArrayList<Customer>actualCustomerList=(ArrayList<Customer>)electricityBillServices.getAllCustomerDetails();
	Assert.assertEquals(expectedCustomerList, actualCustomerList);
}
@After
public void tearDownTestData() {
	ElectricityBillUtil.CUSTOMER_NO_COUNTER=100;
	ElectricityBillUtil.customers.clear();
}
@AfterClass
public static void testDownTestEnv() {
	electricityBillServices=null;
}
}
