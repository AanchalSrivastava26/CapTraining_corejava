
package cm.cg.electricitybill.services;

import java.util.ArrayList;
import java.util.List;

import com.cg.electricitybill.beans.Address;
import com.cg.electricitybill.beans.Bill;
import com.cg.electricitybill.beans.Customer;
import com.cg.electricitybill.beans.Meter;
import com.cg.electricitybill.exceptions.CustomerDetailsNotFoundException;


public interface ElectricityBillServices {
	int acceptCustomerDetails(int mobileNo, String firstName, String lastName, String pancardNo, String emailId, int pincode, int wardNo, String city,
			int billNo, int billDueDate, String billUnit, String billMonth,int meterNo, int consumptionUnits, int meterLoad, String phase,Bill bill);

	int acceptCustomerDetails(int i, int j, String string, String string2, String string3, String string4,
			Address address, Meter meter);
	double calculateBill(int customerNo)throws CustomerDetailsNotFoundException;
	Customer getCustomerDetails(int customerNo)throws CustomerDetailsNotFoundException;
	List<Customer> getAllCustomerDetails();

}
