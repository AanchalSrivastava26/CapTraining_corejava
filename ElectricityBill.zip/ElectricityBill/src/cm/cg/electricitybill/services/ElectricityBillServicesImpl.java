package cm.cg.electricitybill.services;

import java.util.ArrayList;

import java.util.List;

import com.cg.electricitybill.beans.Address;
import com.cg.electricitybill.beans.Bill;
import com.cg.electricitybill.beans.Customer;
import com.cg.electricitybill.beans.Meter;
import com.cg.electricitybill.daoservices.CustomerDAO;
import com.cg.electricitybill.daoservices.CustomerDAOImpl;
import com.cg.electricitybill.exceptions.CustomerDetailsNotFoundException;


public class ElectricityBillServicesImpl implements ElectricityBillServices {
	private CustomerDAO customerDAO=new CustomerDAOImpl();

	@Override
	public int acceptCustomerDetails(int mobileNo, String firstName, String lastName, String pancardNo, String emailId,
			int pincode, int wardNo, String city, int billNo, int billDueDate, String billUnit, String billMonth,
			int meterNo, int consumptionUnits, int meterLoad, String phase, Bill bill) {

		Customer customer=new Customer(mobileNo, firstName, lastName, pancardNo, emailId,
				new Address(pincode, wardNo, city),new Meter(meterNo, consumptionUnits, meterLoad, phase,
						new Bill(billNo, billDueDate, billUnit, billMonth)));

		return customer.getCustomerNo();
	}

	@Override
	public double calculateBill(int customerNo) throws CustomerDetailsNotFoundException {
		Customer customer=this.getCustomerDetails(customerNo);
		double fixedCharge=80.0,energyDuty=134.0,energyTax=1057.0;
		int energyUnits=customer.getMeter().getConsumptionUnits();
		double finalAmount=customer.getMeter().getBill().getBillAmount();
		if(energyUnits>=1 && energyUnits<=100 ) 
			finalAmount=energyUnits*4.30;

		else if(energyUnits>=101 && energyUnits<=300 ) 
			finalAmount=finalAmount+energyUnits*8.03;

		else if(energyUnits>=301 && energyUnits<=500 ) 
			finalAmount=finalAmount+energyUnits*11.05;

		else 
			finalAmount=finalAmount+energyUnits*8.80;
	
		return finalAmount+fixedCharge+energyDuty+energyTax;

	}

	@Override
	public Customer getCustomerDetails(int customerNo) throws CustomerDetailsNotFoundException {

		Customer customer=customerDAO.findOne(customerNo);
		if(customer==null)throw new CustomerDetailsNotFoundException("Customer details not found for customerNo"+customerNo);
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() {

		return customerDAO.findAll();
	}

	@Override
	public int acceptCustomerDetails(int customerNo, int mobileNo, String firstName, String lastName, String pancard, String emailId,
			Address address, Meter meter) {

		Customer customer=new Customer(customerNo,  mobileNo, firstName, lastName, pancard, emailId,
				address, meter);

		return customer.getCustomerNo();
	}
}
