import java.util.Scanner;

public class Format {
	public static void main(String[] args) {
		System.out.println("Person Details:"+"\n");
		System.out.println("____________"+"\n");
		Scanner sc=new Scanner(System.in);
		System.out.print("First Name:");
		String first=sc.nextLine();
		System.out.print("Last Name:");
		String last=sc.nextLine();
		System.out.print("Gender:");
		String gender=sc.nextLine();
		System.out.print("Age:");
		int age=sc.nextInt();
		System.out.print("Weight:");
		double weight=sc.nextDouble();
	}

}
