package com.cg.lab8.client;

import java.util.Scanner;

import com.cg.lab8.thread.RunnableResource;

public class MainClassThread {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		RunnableResource runnableResource=new RunnableResource();

		boolean value=true;
		while(value) {
			System.out.println("enter number which method you want to implement:");
			int num=sc.nextInt();
			switch(num) {
			case 1:

				Thread th1=new Thread(runnableResource,"th1");
				th1.start();
				break;
			case 2:

				Thread th2=new Thread(runnableResource,"th2");
				th2.start();
				break;

			default:
				System.out.println("you entered default case");
				value=false;
				break;
			}

		}

	}}
