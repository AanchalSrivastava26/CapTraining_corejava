package com.cg.lab8.thread;

import java.util.Scanner;

public class RunnableResource implements Runnable{
	public void run() {
		Thread t=Thread.currentThread();
		Scanner sc=new Scanner(System.in);
		int num=0,f=1;
		if(t.getName().equals("th1")) {
			System.out.println("enter number");
			num=sc.nextInt();
			System.out.println("number is :" +num);
		}
		else if(t.getName().equals("th2")) {
			for(int i=1;i<=num;i++) {
				f=f*i;
				System.out.println("factorial of entered number :"+f);
			}
		}
	}
}