package com.cg.lab7;

import java.util.ArrayList;
import java.util.Collections;

public class SortReverseElements{
	public void acceptElements() {
		ArrayList<Integer> arr=new ArrayList<>();
		arr.add(23);
		arr.add(11);
		arr.add(67);
		arr.add(83);
		System.out.println(arr);
		Collections.sort(arr);
		System.out.println("elements after sorting"+arr);
		Collections.reverse(arr);
		System.out.println("elements after reverse"+arr);
	}
	public static void main(String[] args) {
		SortReverseElements s=new SortReverseElements();
		s.acceptElements();
	}
}