package com.cg.lab7;

import java.util.HashMap;

public class GetSquares {

	public HashMap<Integer, Integer> getSquares(){
		HashMap<Integer, Integer> hashmap=new HashMap<>();
			hashmap.put(01, 1);
		hashmap.put(02, 3);
		hashmap.put(03, 5);
		hashmap.put(04, 7);
		hashmap.put(05, 9);
		return hashmap;
	}
public static void main(String[] args) {
	GetSquares squares=new GetSquares();
	System.out.println(squares.getSquares());
}

}
