package com.cg.lab6.client;

import com.cg.lab2.ClassDiagram;
import com.cg.lab2.Gender;
import com.cg.lab6.exception.NameException;

public class MainClass {

	public static void main(String[] args){
		ClassDiagram cd=new ClassDiagram("", "srivastava", 'F');
		System.out.println("First Name:"+cd.getFirstName()+"\n");
		System.out.println("Last Name:"+cd.getLastName()+"\n");
		System.out.println("Gender:"+cd.getGender());
		try {
			Gender gender; 
			  gender = Gender.male; 
			  System.out.println("Gender is "+gender);
			  if(cd.getFirstName().equals("") || cd.getLastName().equals(""))
				  throw new  NameException();
				
		} catch (NameException e) {
			
			System.err.println("first and last names cannot be blank."+e);
		}
	}
}