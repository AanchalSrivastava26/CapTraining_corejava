package com.cg.lab6.beans;

public enum Gender 
	{ male,female }



