package com.cg.lab9;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;

public class ReadWriteFiles {
	
	public static void main(String[] args) throws Exception {
		  FileReader fr =   new FileReader("D:\\credentials.txt"); 
		FileWriter fw = new FileWriter("reverse_output.txt");  
		BufferedReader janus = new BufferedReader(fr);  
	   int i; 
			    while ((i=fr.read()) != -1) 
			      System.out.print((char) i); 
	String data;  
	           while ((data = janus.readLine()) != null){
	    String[] words = data.split(" ");
	    for(String a: words){
	        StringBuilder builder=new StringBuilder(a);
	        System.out.print(builder.reverse().toString());
	    }  
	}
	
}}