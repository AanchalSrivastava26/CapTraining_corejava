package com.cg.eis.pl;


import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;

public class MainClass {
	public static void main(String[] args) {
	Employee emp=new Employee(101,"aanchal", 2000.0, "analyst", 2000.0);
EmployeeService employee1=new EmployeeServiceImpl();
employee1.calulateInsurance("analyst", 400000.0);
System.out.println(emp.toString());
try {
	if(emp.getSalary()<3000.0)
		throw new EmployeeException();
} catch (EmployeeException e) {

	System.err.println("salary cannot be less than Rs. 3000.0"+e);
}

	}

}
