package com.cg.eis.bean;

public class Employee {
	private int id;
	private String name, designation;
	private double insuranceScheme,salary;
	public Employee(int id, String name, double insuranceScheme, String designation, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.insuranceScheme = insuranceScheme;
		this.designation = designation;
		this.salary = salary;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(double insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "id=" + id + ", name=" + name + ", insuranceScheme=" + insuranceScheme + ", designation="
				+ designation + ", salary=" + salary ;
	} 
	

}
