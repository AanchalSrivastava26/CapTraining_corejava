package com.cg.lab2;

public class PersonMain {

	public static void main(String[] args) {
		ClassDiagram cd=new ClassDiagram("aanchal", "srivastava", 'F');
		ClassDiagram cd1=new ClassDiagram("aanchal", "srivastava", 'F',452526125);
		System.out.println("First Name:"+cd.getFirstName()+"\n");
		System.out.println("Last Name:"+cd.getLastName()+"\n");
		System.out.println("Gender:"+cd.getGender());
		Gender gender; 
		gender = Gender.male; 
		System.out.println("Gender is "+gender);
		cd1.displayPhoneNumber();
	}
}
