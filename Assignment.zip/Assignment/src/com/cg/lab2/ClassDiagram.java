package com.cg.lab2;

public class ClassDiagram {

	private String firstName,lastName;
	private char gender;
	private int phoneNo;
	public ClassDiagram() {

	}

	public ClassDiagram(String firstName, String lastName, char gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}
	

	public ClassDiagram(String firstName, String lastName, char gender, int phoneNo) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.phoneNo = phoneNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public int getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}
	public void displayPhoneNumber() {
		System.out.println("entered phone number is :"+this.phoneNo);
	}
	
}
