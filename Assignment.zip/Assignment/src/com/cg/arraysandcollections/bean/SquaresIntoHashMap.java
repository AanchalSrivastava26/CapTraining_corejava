package com.cg.arraysandcollections.bean;

import java.util.HashMap;
import java.util.Map;

public class SquaresIntoHashMap {
	public static Map<Integer, Integer> getSquares(int[] numbers){
		Map<Integer, Integer> squares=new HashMap<>();
		for (int i = 0; i < numbers.length; i++) {
			squares.put(numbers[i], Math.multiplyExact(numbers[i], numbers[i]));
		}
		return squares;
	}

}
