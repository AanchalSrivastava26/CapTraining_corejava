package com.cg.arraysandcollections.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.arraysandcollections.bean.RemoveElementsfromList;
import com.cg.arraysandcollections.bean.ReverseAndSort;
import com.cg.arraysandcollections.bean.SquaresIntoHashMap;

public class MainClass {
	public static void main(String args[]) {
		int[] array= {12,23,96,45};
		System.out.println("array elemnts reverse and sorted");
		array=ReverseAndSort.getSorted(array);
		for (int i = 0; i < array.length; i++)
			System.out.println(array[i]);
		/*ArrayList<String> stringList=new ArrayList<>();
		StringBuilder s1=new StringBuilder("gopika");
		StringBuilder s2=new StringBuilder("abc");
		stringList=(ArrayList<String>) StringOutputToArrayList.stringOperation(s1, s2);
		for (String string : stringList) {
			System.out.println(string);
		}*/
		System.out.println("removing elements from one list using another list");
		List<Integer> list1=new ArrayList<>();
		List<Integer> list2=new ArrayList<>();
		list1.add(2);list1.add(3);list1.add(8);list1.add(6);
		list2.add(2);list2.add(3);
		list1=RemoveElementsfromList.removeElements(list1, list2);
		for (Integer integer : list1) 
			System.out.println(integer);
		System.out.println("sqaures of numbers into hashmap");
		int[] numbers= {2,4,5,8,9,12};
		Map<Integer, Integer> sqaures=new HashMap<>();
		sqaures=SquaresIntoHashMap.getSquares(numbers);
		for(Integer key: sqaures.keySet())
		    System.out.println(key+":"+sqaures.get(key));
		System.out.println("sort the product the strings");
		ArrayList<String> products=new ArrayList<>();
		products.add("apple");products.add("google");products.add("microsoft");products.add("amazon");
		Collections.sort(products);
		for (String string : products) 
			System.out.println(string);

	}
}

