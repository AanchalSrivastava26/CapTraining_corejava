package com.cg.lab4.client;
import com.cg.lab4.beans.Account;
import com.cg.lab4.beans.Person;
import com.cg.lab4.exception.ImproperAgeException;


public class MainClass {
	public static void main(String[] args)  {
		Account account=new Account(1256136, 2000.0, new Person("smith", 10.0f));
		account.deposit(2000.0);
		Account account1=new Account(532615316, 3000.0, new Person("Kathy", 25.0f));
		account1.withdraw(2000.0);
		
		try {
			if(account.getAccountHolder().getAge()<=15.0f)
				throw new ImproperAgeException();
		} 
		catch (ImproperAgeException e) {
			
			System.err.println("age cannot be less than or equal to 15"+e);
		}
	}
}
