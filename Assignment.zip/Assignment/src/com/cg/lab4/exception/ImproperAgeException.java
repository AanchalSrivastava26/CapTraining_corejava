package com.cg.lab4.exception;

public class ImproperAgeException extends Exception{

	public ImproperAgeException() {
		super();
		
	}

	public ImproperAgeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	
	}

	public ImproperAgeException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public ImproperAgeException(String message) {
		super(message);
		
	}

	public ImproperAgeException(Throwable cause) {
		super(cause);
	
	}
	

}
