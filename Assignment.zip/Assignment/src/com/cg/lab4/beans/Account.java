package com.cg.lab4.beans;

public class Account {
	private long accNum;
	private double balance;
	private Person accountHolder;
	public Account(long accNum, double balance, Person accountHolder) {
		super();
		this.accNum = accNum;
		this.balance = balance;
		this.accountHolder = accountHolder;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(Person accountHolder) {
		this.accountHolder = accountHolder;
	}
	public void deposit(double amount) {
		amount=balance+2000.0;
		System.out.println("balance in Smith's account after deposit :"+amount);

	}
	public void withdraw(double amount) {
		amount=balance-2000.0;
		System.out.println("balance in Kathy's account after withdrawl :"+amount);
	}

}
