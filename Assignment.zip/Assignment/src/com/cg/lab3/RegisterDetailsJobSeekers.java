package com.cg.lab3;

public class RegisterDetailsJobSeekers {
	private String str;

	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}
	public RegisterDetailsJobSeekers(String str) {
		super();
		this.str = str;
	}
	public void validateDetails(String str) {
		System.out.println(str.endsWith("_job"));
		int l=str.length();
		for(int i=0;i<l;i++) {
			if(str.charAt(i)=='_' && i==8) {
				System.out.println("there are eight characters before _job");
				break;
			}	
		}
	}
	public static void  main(String[] args) {
		RegisterDetailsJobSeekers register=new RegisterDetailsJobSeekers("aanchals_job");
		register.validateDetails("aanchals_job");
	}

}