package com.cg.lab3;

import java.util.Scanner;

public class StringMainClass {
	public static void main(String[] args) {

		AcceptString acceptString=new AcceptString();
		Scanner sc=new Scanner(System.in);
		boolean value=true;
		int num=0;
		System.out.println("01. Add the String to itself");
		System.out.println("02. Replace odd positions with #");
		System.out.println("03. Remove duplicate characters in the String");
		System.out.println("04. Change odd characters to upper case"+"\n");
		while(value) {
			System.out.println("enter number which method you want to implement:");
			num=sc.nextInt();
			switch(num) {
			case 1:
				acceptString.acceptString();
				break;
			case 2:
				acceptString.replace("aanchal");
				break;
			case 3:
				acceptString.removeDuplicates("aanchall");
				break;
			case 4:
				acceptString.upperCase("aanchal");
				break;
			default:
				System.out.println("you entered default case");
				value=false;
				break;
			}
		} 
	}
}
