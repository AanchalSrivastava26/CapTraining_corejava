package com.cg.lab3;

import java.util.Arrays;
import java.util.Scanner;

public class PositiveString {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter string to be checked");
		String input=sc.nextLine();
		char[] charArray = input.toCharArray();
		Arrays.sort(charArray);
		String sortedString = new String(charArray);
		System.out.println("Positive string :"+sortedString); 
	}
}
