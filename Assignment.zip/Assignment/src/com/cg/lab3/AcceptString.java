package com.cg.lab3;

import java.util.Scanner;

public class AcceptString {
	public String acceptString() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter string");
		String second=sc.nextLine();
		String outputString=" ";
		outputString=second.concat(second);
		System.out.println(outputString);
		return outputString;
	}
	public String replace(String s) {
		int length=s.length();
		for(int i=0;i<length;i++)
			if(i%2!=0) 
				s=s.replace(s.charAt(i), '#');
		System.out.println(s);
		return s;
	}
	public String removeDuplicates(String s) {
		int i,j;
		int length=s.length();
		for(i=0;i<length;i++)
		{for(j=i+1;j<length;j++) 
			if(s.charAt(i)==s.charAt(j) && i!=j) 
				System.out.println("duplicate character :"+s.charAt(i));
		}
		return s;
	}
	public String upperCase(String s) {
		int length=s.length();
		String outputString="";
		for(int i=0;i<length;i++)
			if(i%2!=0) 
				outputString+=Character.toUpperCase(s.charAt(i));
		System.out.println("output string:"+outputString);
		return s;

	}
}
