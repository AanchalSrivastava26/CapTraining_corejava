package com.cg.collectiondemo.functionalinterface;
@FunctionalInterface
public interface Condition2<T>{
	boolean checkStartsWith(T e);
}