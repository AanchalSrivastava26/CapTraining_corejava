package com.cg.collectiondemo.functionalinterface;
import com.cg.collectiondemo.beans.Associate;

@FunctionalInterface
public interface Condition<T> {
	boolean startsWith(Associate associate);
}