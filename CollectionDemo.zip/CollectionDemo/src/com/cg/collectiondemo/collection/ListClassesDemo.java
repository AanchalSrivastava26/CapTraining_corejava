package com.cg.collectiondemo.collection;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import com.cg.collectiondemo.beans.Associate;

public class ListClassesDemo {
	public static void arrayListClassDemo() {
		ArrayList<Associate> associates=new ArrayList<>();
		//insert
		associates.add(new Associate(111,15000,"aanchal","srivastava"));
		associates.add(new Associate(112,35000,"gopi","xyz"));
		associates.add(new Associate(113,15000,"abc","def"));
		associates.add(new Associate(114,15000,"a","b"));
		//search
		Associate associateToBeSearched=new Associate(111,15000,"aanchal","srivastava");
		int idx=associates.indexOf(associateToBeSearched);
		System.out.println(idx);
		//remove
		associates.remove(1);
		//sort
		Collections.sort(associates);
		System.out.println(associates);
	}
}