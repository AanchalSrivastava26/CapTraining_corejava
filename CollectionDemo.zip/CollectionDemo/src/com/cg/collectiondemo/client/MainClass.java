package com.cg.collectiondemo.client;

import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.cg.collectiondemo.beans.Associate;
import com.cg.collectiondemo.collection.ListClassesDemo;

public class MainClass {
	public static void main(String[] args) {
	ListClassesDemo.arrayListClassDemo();
	
	ArrayList<Associate>associateList=new ArrayList<>();
	associateList.add(new Associate(101, 23220, "aanchal", "srivastava"));
	associateList.add(new Associate(102, 222620, "prachi", "srivastava"));
	associateList.add(new Associate(103, 222620, "dji", "dkdddwqq"));
	associateList.add(new Associate(104, 222620, "dwsjd", "djqddqd"));
	
	/*Comparator<Associate>associateComparator=(a1,a2)->a1.getBasicSalary()-a2.getBasicSalary();
	Collections.sort(associateList, associateComparator);
	
	Collections.sort(associateList,(a1,a2)->a1.getBasicSalary()-a2.getBasicSalary());
	printAssociateDetails(associateList,(a)->a.getFirstName().startsWith("a"));	
	printAssociateDetails1(associateList,(a)->a.getFirstName().startsWith("a"),e->System.out.println(e));	
	associateList.forEach((a)->System.out.println(a));*/
	
	Stream<Associate> stream1=associateList.stream();
	Stream<Associate> stream2=stream1.distinct();
	Stream<Associate> stream3=stream2.filter((associate)->associate.getFirstName().startsWith("a"));
	System.out.println(stream3.count());
	stream3.forEach((a)->System.out.println(a));
	associateList.stream()
	.distinct()
	.filter((a)->a.getFirstName().startsWith("p"));
	System.out.println(associateList.stream().map(associate->associate.getAssociateId()));
	
}
	@FunctionalInterface
	public interface Condition {
		boolean startsWith(Associate associate);

	}
@FunctionalInterface
public interface Condition2<T>{
	boolean checkStartsWith(T e);
}
	private static void printAssociateDetails(List<Associate>associateList,Condition condition) {
	for (Associate associate : associateList) 
		if(condition.startsWith(associate))
			System.out.println(associate);
		
	}
	
	private static void printAssociateDetails1(List<Associate>associateList,Condition2<Associate> condition,Consumer<Associate>consumer) {
		for (Associate associate : associateList) 
			if(condition.checkStartsWith(associate))
				System.out.println(associate);
			
		}
}