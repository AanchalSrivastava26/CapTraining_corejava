package com.cg.iodemo.client;

import java.io.File;
import java.io.IOException;

import com.cg.iodemo.ObjectSerializationDemo;
import com.cg.iodemo.ReadWriteDemo;

public class MainClass {

	public static void main(String[] args) {
		File file=new File("d:\\	DataFile.txt");
		try {
			if(!file.exists())
			file.createNewFile();
			System.out.println(file.canWrite());
			System.out.println(file.getName());
			System.out.println(file.canExecute());
			File fromFile=new File("D:\\");
			File toFile=new File("d:\\"+fromFile.getName());
			ReadWriteDemo.byteReadWriteDemo(fromFile, toFile);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
		
	/*	try {
		File file=new File("d:\\AssociateData.txt");
		ObjectSerializationDemo.doSerialization(file);
		ObjectSerializationDemo.doDeSerialization(file);
		}
		catch(IOException | ClassNotFoundException e) {
			e.printStackTrace();*/
		}
	}


