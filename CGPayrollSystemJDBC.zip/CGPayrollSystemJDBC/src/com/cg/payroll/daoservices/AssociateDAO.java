package com.cg.payroll.daoservices;

import java.sql.SQLException;
import java.util.List;

import com.cg.payroll.beans.Associate;

public interface AssociateDAO {
	 Associate save(Associate associate) throws SQLException;
			boolean update(Associate associate);
			Associate findOne(int associateId) throws SQLException;
			List<Associate> findAll() throws SQLException;
}


