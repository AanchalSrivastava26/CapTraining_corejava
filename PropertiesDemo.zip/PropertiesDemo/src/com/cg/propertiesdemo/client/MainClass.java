package com.cg.propertiesdemo.client;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
public class MainClass {

	public static void main(String[] args) {
		try {
			Properties projectProperties=new Properties();
			projectProperties.load(new FileInputStream(".resources\\project.properties"));  
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}
