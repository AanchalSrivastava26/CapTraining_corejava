package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountDetailsNotFoundException;
import com.cg.mra.util.AccountUtil;


public class AccountServiceImpl implements AccountService {

	private AccountDao accountDao = new AccountDaoImpl();
	public AccountServiceImpl(AccountDao accountDao) {
		super();
		this.accountDao = accountDao;
	}
	public AccountServiceImpl() {

	}

	@Override
	public Account getAccountDetails(String mobileNo) throws AccountDetailsNotFoundException{

		Account account= accountDao.getAccountDetails(mobileNo);
		if(account== null) throw new AccountDetailsNotFoundException("Error: Given Account id does not Exist.");
		else
			return account;
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) throws AccountDetailsNotFoundException {

		if(mobileNo.length() == 0 || mobileNo.length()<10) throw new AccountDetailsNotFoundException("Error: Cannot Recharge Account as Given Mobile No Does Not Exist.");//throwing exception if mobile number is less than 10 digits
		else
			return accountDao.rechargeAccount(mobileNo, rechargeAmount);
	}
}


