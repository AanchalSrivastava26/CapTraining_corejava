package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountDetailsNotFoundException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) throws AccountDetailsNotFoundException {
		AccountService accountService=new AccountServiceImpl();
		Scanner sc=new Scanner(System.in);
		boolean value=true;
		int num=0;
		double rechargeAmount;
		String mobileNo;
		Account account ;
		while(value) {
			System.out.println("01. Account Balance Enquiry");		//activities to perform
			System.out.println("02. Recharge Account");
			System.out.println("03. Exit"+"\n");
			System.out.println("enter number which method you want to implement:");
			num=sc.nextInt();
			switch(num) {												//switch to display menu to perform various activities
			case 1:

				System.out.println("Enter mobile no");
				mobileNo=sc.next();
				accountService.getAccountDetails(mobileNo);
				try {
					account= accountService.getAccountDetails(mobileNo);
					System.out.println("Your Current Balance is Rs. "+account.getAccountBalance());
				} catch (AccountDetailsNotFoundException e) {}  

				break;
			case 2:
				System.out.println("Enter mobile no");
				mobileNo = sc.nextLine();
				System.out.println("Enter recharge amount");
				rechargeAmount=sc.nextDouble();
				try {
					account = accountService.getAccountDetails(mobileNo);
					rechargeAmount= accountService.rechargeAccount(mobileNo, rechargeAmount);
					System.out.println("Your Account Recharged Successfully");
					System.out.println("Hello "+account.getCustomerName()+",Available Balance is "+account.getAccountBalance());
				} catch (AccountDetailsNotFoundException e) {}
				break;
			case 3:
				System.out.println("you entered default case");
				System.exit(0);
				break;
			default:
			}
		}

	}

}
