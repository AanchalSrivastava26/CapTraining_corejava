package com.cg.mra.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountDetailsNotFoundException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
import com.cg.mra.util.AccountUtil;

public class AccountUtilTest {
	static AccountService accountService;
	@BeforeClass
	public static void setUpTestEnv() {
		accountService=new AccountServiceImpl();
	}
	@Before
	public void setUpTestData() {
		AccountUtil.accounts.put("Vaishali", new Account("Prepaid", "Vaishali", 200));
		AccountUtil.accounts.put("Megha", new Account("Prepaid", "Megha", 200));
	}
	@Test(expected=AccountDetailsNotFoundException.class)			//test to check recharge account method
	public void testRechargeAccount() throws AccountDetailsNotFoundException{
		accountService.rechargeAccount("9010210131", 200);
	}

	@After
	public void tearDownTestData() {
		AccountUtil.accounts.clear();
	}
	@AfterClass
	public static void testDownTestEnv() {
		accountService=null;
	}

}
