package com.cg.mra.util;

import java.util.HashMap;
import com.cg.mra.beans.Account;

public class AccountUtil {
	public static HashMap<String,Account>accounts=new HashMap<>();//declaring hashmap with key of type String and value of type Account.
}
