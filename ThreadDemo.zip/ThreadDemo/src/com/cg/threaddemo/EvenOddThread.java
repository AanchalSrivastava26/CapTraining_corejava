package com.cg.threaddemo;


public class EvenOddThread implements Runnable{
	public void run() {
		Thread t=Thread.currentThread();
		try {
			if(t.getName().equals("th1")) {
				for(int i=1;i<=30;i++) {
					Thread.sleep(1000);
					if(i%2!=0)
					System.out.println(i+" "+t.getName());
				}
			}
			else if(t.getName().equals("th2")) {
				for(int i=1;i<=30;i++) {
				
					if(i%2==0)
					System.out.println(i+" "+t.getName());
				}
			}
		}
		catch (InterruptedException e) {
			e.printStackTrace();
			
		}
	}

}
