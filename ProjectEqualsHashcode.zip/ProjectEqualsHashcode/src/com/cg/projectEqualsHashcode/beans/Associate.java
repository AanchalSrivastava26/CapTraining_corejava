package com.cg.projectEqualsHashcode.beans;

public class Associate {
	private String firstName,secondName;
	private int associateId,basicSalary,totalSalary;
	private Address address;

	

	public Associate(String firstName, String secondName, int associateId, int basicSalary) {
		super();
		this.firstName = firstName;
		this.secondName = secondName;
		this.associateId = associateId;
		this.basicSalary = basicSalary;
	}
	
	

	
	public Associate(String firstName, String secondName, int associateId, int basicSalary,Address address) {
		super();
		this.firstName = firstName;
		this.secondName = secondName;
		this.associateId = associateId;
		this.basicSalary = basicSalary;
		this.address=address;                                                                                                                                                                   
	}




	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSecondName() {
		return secondName;
	}
	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public int getTotalSalary() {
		return totalSalary;
	}
	public void setTotalSalary(int totalSalary) {
		this.totalSalary = totalSalary;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + associateId;
		result = prime * result + basicSalary;
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((secondName == null) ? 0 : secondName.hashCode());
		result = prime * result + totalSalary;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Associate other = (Associate) obj;
		if (associateId != other.associateId)
			return false;
		if (basicSalary != other.basicSalary)
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (secondName == null) {
			if (other.secondName != null)
				return false;
		} else if (!secondName.equals(other.secondName))
			return false;
		if (totalSalary != other.totalSalary)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Associate [firstName=" + firstName + ", secondName=" + secondName + ", associateId=" + associateId
				+ ", basicSalary=" + basicSalary + ", totalSalary=" + totalSalary + "]";
	}
	

}
