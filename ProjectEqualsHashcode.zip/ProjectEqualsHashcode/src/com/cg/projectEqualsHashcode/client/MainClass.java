package com.cg.projectEqualsHashcode.client;

import com.cg.projectEqualsHashcode.beans.Address;
import com.cg.projectEqualsHashcode.beans.Associate;

public class MainClass {

	public static void main(String[] args) {
		Associate associate=new Associate("aanchal", "srivastava", 101, 30000,new Address(123412, "lucknow"));
		Associate associate1=new Associate("aanchal", "srivastava", 101, 30000,new Address(123412,"lucknow"));
		
		if(associate==associate1)
			System.out.println("same references");
		else
			System.out.println("not same references");
		
		if(associate.equals(associate1))
			System.out.println("same data");
		else
			System.out.println("not same data");

	}

}
