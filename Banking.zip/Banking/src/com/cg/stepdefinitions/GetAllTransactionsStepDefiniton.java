package com.cg.stepdefinitions;

import static org.junit.Assert.assertEquals;
import java.util.ArrayList;
import java.util.stream.Collectors;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingUtil;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetAllTransactionsStepDefiniton {

	static BankingServices bankingServices;
	Account expectedAccount=new Account(101, 3216, "savings", "active", 3400.0f);


	ArrayList<Transaction> transaction;


	@Before
	public void setUpTestData() {
		Account account1=new Account(101, 3216, "savings", "active", 3400.0f);
		Account account2=new Account(102, 2347, "savings", "active", 7000.0f);


		BankingUtil.accounts.put(account1.getAccountNo(), account1);
		BankingUtil.accounts.put(account2.getAccountNo(), account2);
		BankingUtil.ACCOUNT_ID_COUNTER=102;
	}

	@Given("^create an object$")
	public void create_an_object() throws Throwable {
		bankingServices=new BankingServicesImpl();
	}

	@When("^user enters account number$")
	public void user_enters_account_number() throws Throwable {
		transaction=(ArrayList<Transaction>) bankingServices.getAccountAllTransaction(101);


	}

	@Then("^method should return list of transactions$")
	public void method_should_return_list_of_transactions() throws Throwable {
		ArrayList<Transaction> transactions=new ArrayList<>(BankingUtil.transactions.values());
		ArrayList<Transaction> expectedTransactions=(ArrayList<Transaction>)
				transactions.stream().filter(t->t.getAccount().getAccountNo()==101).collect(Collectors.toList());
		assertEquals(expectedTransactions, transaction);


	}



}
