package com.cg.stepdefinitions;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingUtil;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetAccountDetailsStepDefinition {

	static BankingServices bankingServices;
	Account expectedAccount=new Account(101, 3216, "savings", "active", 3400.0f);
	Account account1;


	@Before
	public void setUpTestData() {
		Account account1=new Account(101, 3216, "savings", "active", 3400.0f);
		Account account2=new Account(102, 2347, "savings", "active", 7000.0f);

		BankingUtil.accounts.put(account1.getAccountNo(), account1);
		BankingUtil.accounts.put(account2.getAccountNo(), account2);
		BankingUtil.ACCOUNT_ID_COUNTER=102;
	}

	@Given("^create an object of service class$")
	public void create_an_object_of_service_class() throws Throwable {
		bankingServices=new BankingServicesImpl();
	}

	@When("^user will enter account number$")
	public void user_will_enter_account_number() throws Throwable {
		account1=bankingServices.getAccountDetails(101);
	}

	@Then("^method should return object$")
	public void method_should_return_object() throws Throwable {

		assertEquals(account1, expectedAccount);

	}
}
