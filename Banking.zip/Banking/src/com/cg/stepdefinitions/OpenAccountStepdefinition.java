package com.cg.stepdefinitions;

import static org.junit.Assert.assertEquals;
import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingUtil;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OpenAccountStepdefinition {

	static BankingServices bankingServices;

	Account actualAccount;


	@Before
	public void setUpTestData() {
		Account account1=new Account(101, 3216, "savings", "active", 3400.0f);
		Account account2=new Account(102, 2347, "savings", "active", 7000.0f);

		BankingUtil.accounts.put(account1.getAccountNo(), account1);
		BankingUtil.accounts.put(account2.getAccountNo(), account2);
		BankingUtil.ACCOUNT_ID_COUNTER=102;
	}

	@Given("^create the service object$")
	public void create_the_service_object() throws Throwable {
		bankingServices=new BankingServicesImpl();
	}
	@When("^user will enter initial balance and account type$")
	public void user_will_enter_initial_balance_and_account_type() throws Throwable {
		actualAccount=bankingServices.openAccount("savings", 1000.0f);
	}

	@Then("^method should return account object$")
	public void method_should_return_account_object() throws Throwable {
		assertEquals(103, actualAccount.getAccountNo());
	}



}
