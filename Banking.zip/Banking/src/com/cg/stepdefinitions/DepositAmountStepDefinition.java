package com.cg.stepdefinitions;



import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingUtil;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DepositAmountStepDefinition {
	
	static BankingServices bankingServices;

	Account account1;
	Account account2;


		@Before
	public void setUpTestData() {
		 account1=new Account(101, 3216, "savings", "active", 3400.0f);
		 account2=new Account(102, 2347, "savings", "active", 7000.0f);

		BankingUtil.accounts.put(account1.getAccountNo(), account1);
		BankingUtil.accounts.put(account2.getAccountNo(), account2);
		BankingUtil.ACCOUNT_ID_COUNTER=102;
	}

	
	@Given("^create service object$")
	public void create_service_object() throws Throwable {
		bankingServices=new BankingServicesImpl();
	}

	@When("^user will enter account number and amount$")
	public void user_will_enter_account_number_and_amount() throws Throwable {
		bankingServices.depositAmount(101, 200.0f);
	}

	@Then("^method should return account balance$")
	public void method_should_return_account_balance() throws Throwable {
		assertEquals(3600.0f, account1.getAccountBalance(), 1000.0f);
		
	}

}
