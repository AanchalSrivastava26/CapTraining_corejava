package com.cg.stepdefinitions;

import static org.testng.Assert.assertEquals;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingUtil;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FundTransferStepDefinition {
	
	static BankingServices bankingServices;
	Account account1;
	Account account2;
	boolean actualResult;

	
	@Before
public void setUpTestData() {
	 account1=new Account(101, 3216, "savings", "active", 3400.0f);
	 account2=new Account(102, 2347, "savings", "active", 7000.0f);

	BankingUtil.accounts.put(account1.getAccountNo(), account1);
	BankingUtil.accounts.put(account2.getAccountNo(), account2);
	BankingUtil.ACCOUNT_ID_COUNTER=102;
}
	

@Given("^create the service class object$")
public void create_the_service_class_object() throws Throwable {
	bankingServices=new BankingServicesImpl();
}

@When("^user will enter accounts among which transaction happens along with pin number and amount$")
public void user_will_enter_accounts_among_which_transaction_happens_along_with_pin_number_and_amount() throws Throwable {
   actualResult=bankingServices.fundTransfer(101, 102, 500.0f, 2347);
}

@Then("^method should return either true or false$")
public void method_should_return_either_true_or_false() throws Throwable {
	assertEquals(actualResult, true);
   
}



}
