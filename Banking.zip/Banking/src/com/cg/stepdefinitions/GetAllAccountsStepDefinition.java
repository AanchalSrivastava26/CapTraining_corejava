package com.cg.stepdefinitions;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Assert;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingUtil;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GetAllAccountsStepDefinition {
	
	static BankingServices bankingServices;
	Account expectedAccount=new Account(101, 3216, "savings", "active", 3400.0f);
	Account account1;


	@Before
	public void setUpTestData() {
		Account account1=new Account(101, 3216, "savings", "active", 3400.0f);
		Account account2=new Account(102, 2347, "savings", "active", 7000.0f);
	

		BankingUtil.accounts.put(account1.getAccountNo(), account1);
		BankingUtil.accounts.put(account2.getAccountNo(), account2);
		BankingUtil.ACCOUNT_ID_COUNTER=102;
	}
	
	@Given("^an object of service class$")
	public void an_object_of_service_class() throws Throwable {
		bankingServices=new BankingServicesImpl();
	}

	@When("^we call getAll method$")
	public void we_call_getAll_method() throws Throwable {
	  bankingServices.getAllAccountDetails();
	}

	@Then("^method should return list of accounts$")
	public void method_should_return_list_of_accounts() throws Throwable {
		ArrayList<Account> expectedAccountList=new ArrayList<>(BankingUtil.accounts.values());
		ArrayList<Account>actualAccountList=(ArrayList<Account>)bankingServices.getAllAccountDetails();
	assertEquals(actualAccountList, expectedAccountList);
	    
	}



}
