package com.cg.stepdefinitions;

import static org.junit.Assert.assertEquals;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingUtil;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WithdrawAmountStepDefinition {
	
	static BankingServices bankingServices;

	Account account1;
	Account account2;
	
	
	@Before
	public void setUpTestData() {
		 account1=new Account(101, 3216, "savings", "active", 3400.0f);
		 account2=new Account(102, 2347, "savings", "active", 7000.0f);

		BankingUtil.accounts.put(account1.getAccountNo(), account1);
		BankingUtil.accounts.put(account2.getAccountNo(), account2);
		BankingUtil.ACCOUNT_ID_COUNTER=102;
	}
	@Given("^create service class object$")
	public void create_service_class_object() throws Throwable {
		bankingServices=new BankingServicesImpl();
	}

	@When("^user will enter account number and amount to be withdrawn$")
	public void user_will_enter_account_number_and_amount_to_be_withdrawn() throws Throwable {
	   bankingServices.withdrawAmount(102, 1000.0f, 2347);
	}

	@Then("^method should return balance of the account from which amount is withdrawn$")
	public void method_should_return_balance_of_the_account_from_which_amount_is_withdrawn() throws Throwable {
		assertEquals(6000.0f, account2.getAccountBalance(), 1000.0f);
	}



}
