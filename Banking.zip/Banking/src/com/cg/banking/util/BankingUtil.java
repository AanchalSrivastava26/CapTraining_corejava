package com.cg.banking.util;

import java.util.HashMap;


import com.cg.banking.beans.Account;


import com.cg.banking.beans.Transaction;



public class BankingUtil {

	public static int ACCOUNT_ID_COUNTER=100;
	public static int TRANSACTION_ID_COUNTER=100;
	public static HashMap<Long,Account>accounts=new HashMap<>();
	public static HashMap<Integer,Transaction>transactions=new HashMap<>();
	
	public static int getACCOUNT_ID_COUNTER() {
		return ++ACCOUNT_ID_COUNTER;
	}

	public static int getTRANSACTION_ID_COUNTER() {
		return ++TRANSACTION_ID_COUNTER;
	}
	

}

