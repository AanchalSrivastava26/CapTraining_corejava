package com.cg.banking.services;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDao;
import com.cg.banking.daoservices.AccountDaoImpl;

import com.cg.banking.daoservices.TransactionDao;
import com.cg.banking.daoservices.TransactionDaoImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	private AccountDao accountDao;
	private TransactionDao transactionDao;
	public BankingServicesImpl() {
		accountDao=new AccountDaoImpl();
		transactionDao=new TransactionDaoImpl();
	}
	public BankingServicesImpl(AccountDao accountDao) {
		super();
		this.accountDao = accountDao ;
	}

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account=new Account(accountType,initBalance);
		account.setPinNumber((int)(Math.random()*11182));
		account.setStatus("active");
		accountDao.save(account);
		return account;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		account.setAccountBalance(amount+account.getAccountBalance());
		transactionDao.save(new Transaction(amount, "deposit", account));
		accountDao.update(account);
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		account.setAccountBalance(account.getAccountBalance()-amount);
		transactionDao.save(new Transaction(amount, "withdrawl", account));
		accountDao.update(account);
		return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account accountTo=getAccountDetails(accountNoTo);
		Account accountFrom=getAccountDetails(accountNoFrom);
		if(pinNumber==accountFrom.getPinNumber()) {

			if(accountFrom.getAccountBalance()>transferAmount) {
				accountTo.setAccountBalance(accountTo.getAccountBalance()+transferAmount);
				accountFrom.setAccountBalance(accountFrom.getAccountBalance()-transferAmount);
				transactionDao.save(new Transaction(transferAmount, "transferred",accountTo));
				accountDao.update(accountTo);
				transactionDao.save(new Transaction(transferAmount, "transferred",accountFrom));
				accountDao.update(accountFrom);
				return true;
			}
			else 

				throw new InsufficientAmountException("insufficient amount");

		}
		else
			throw new InvalidPinNumberException("please enter correct pin");
	}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account=accountDao .findOne(accountNo);
		if(account==null)throw new AccountNotFoundException("Account not found for accountNo"+accountNo);
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {

		return accountDao .findAll();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		Account acc=getAccountDetails(accountNo);

		return transactionDao .findAll(acc.getAccountNo());
	}
	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account acc=getAccountDetails(accountNo);
		if(acc.getStatus().equals("blocked"))
	
		return "blocked";
		else
		return "active";
	}


}
