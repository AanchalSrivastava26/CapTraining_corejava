package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingUtil;


public class TransactionDaoImpl implements TransactionDao{

	@Override
	public Transaction save(Transaction transaction) {
		transaction.setTransactionId(BankingUtil.getTRANSACTION_ID_COUNTER());
		BankingUtil.transactions.put(transaction.getTransactionId(),transaction);
		return transaction;
	}

	@Override
	public boolean update(Transaction transaction) {
		BankingUtil.transactions.put(transaction.getTransactionId(),transaction);
		return true;
	}

	@Override
	public Transaction findOne(int transactionId) {
	
		return BankingUtil.transactions.get(transactionId);
	}

	@Override
	public List<Transaction> findAll(long accountNo) {
		
		List<Transaction> list=new ArrayList<>();
		for(Transaction transaction:new ArrayList<>(BankingUtil.transactions.values())) {
			if(transaction.getAccount().getAccountNo()==accountNo)
				list.add(transaction);
		}
		return list ;
	}



}
