package com.cg.inheritanceConcepts.beans;

public final class GraduateStudent extends Student{
	private String department,universityName;
	private int internalMarks,externalMarks,totalMarks;
	
	
	
	public GraduateStudent(int studentRollNo, int noOfSubjects, String firstName, String lastName,String department,
			String universityName,int internalMarks,int externalMarks) {
		super(studentRollNo, noOfSubjects, firstName, lastName);
		this.department=department;
		this.externalMarks=externalMarks;
		this.internalMarks=internalMarks;
		this.universityName=universityName;
	
	}



	public String getDepartment() {
		return department;
	}



	public void setDepartment(String department) {
		this.department = department;
	}



	public String getUniversityName() {
		return universityName;
	}



	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}



	public int getInternalMarks() {
		return internalMarks;
	}



	public void setInternalMarks(int internalMarks) {
		this.internalMarks = internalMarks;
	}



	public int getExternalMarks() {
		return externalMarks;
	}



	public void setExternalMarks(int externalMarks) {
		this.externalMarks = externalMarks;
	}



	public int getTotalMarks() {
		return totalMarks;
	}



	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}



	public void calculateMarks() {
		totalMarks=internalMarks*30+externalMarks*100;
		setTotalMarks(totalMarks);
	}





}
