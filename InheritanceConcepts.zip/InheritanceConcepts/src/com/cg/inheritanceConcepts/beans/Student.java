package com.cg.inheritanceConcepts.beans;

public abstract class Student {
	private int studentRollNo,noOfSubjects,totalMarks;
	private String firstName,lastName;
	public Student() {
		super();
	}
	public Student(int studentRollNo, int noOfSubjects, String firstName, String lastName) {
		super();
		this.studentRollNo = studentRollNo;
		this.noOfSubjects = noOfSubjects;
		this.firstName = firstName;
		this.lastName = lastName;
	
	}
	public int getStudentRollNo() {
		return studentRollNo;
	}
	public void setStudentRollNo(int studentRollNo) {
		this.studentRollNo = studentRollNo;
	}
	public int getNoOfSubjects() {
		return noOfSubjects;
	}
	public void setNoOfSubjects(int noOfSubjects) {
		this.noOfSubjects = noOfSubjects;
	}
	public int getTotalMarks() {
		return totalMarks;
	}
	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

public abstract void calculateMarks();



}
