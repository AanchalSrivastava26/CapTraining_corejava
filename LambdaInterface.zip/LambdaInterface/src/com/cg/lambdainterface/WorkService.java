package com.cg.lambdainterface;

        @FunctionalInterface
public interface WorkService {
        	void doSomeWork();

}
