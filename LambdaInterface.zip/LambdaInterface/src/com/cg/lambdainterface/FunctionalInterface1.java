package com.cg.lambdainterface;


@FunctionalInterface
public interface FunctionalInterface1 {
	String upperCase(String str);
	

}
