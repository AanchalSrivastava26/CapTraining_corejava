package com.cg.lambdainterface;

@FunctionalInterface
public interface FunctionalInterface3 {
	int calculateLength(String s);

}
