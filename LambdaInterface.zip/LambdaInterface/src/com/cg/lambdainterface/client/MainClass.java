package com.cg.lambdainterface.client;

import com.cg.lambdainterface.FunctionalInterface1;
import com.cg.lambdainterface.FunctionalInterface2;
import com.cg.lambdainterface.FunctionalInterface3;
import com.cg.lambdainterface.WorkService;

public class MainClass {

	public static void main(String[] args) {

		FunctionalInterface1 ref1=(str)->str.toUpperCase();
		System.out.println(ref1.upperCase("aanchal"));

		FunctionalInterface2 ref2=(a,b)->a+b;
		System.out.println(ref2.add(200,2728));

		FunctionalInterface3 ref3=(str)->str.length();
		System.out.println(ref3.calculateLength("my name is aanchal srivastava"));

		callForWork(()->System.out.println("doing my work"));


	}
	public static void callForWork(WorkService workService) {
		workService.doSomeWork();
	}
	

}
