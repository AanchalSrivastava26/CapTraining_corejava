package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public class PayrollServicesImpl implements PayrollServices{


	private AssociateDAO associateDAO;
	public PayrollServicesImpl() {
		associateDAO=new AssociateDAOImpl();
	}
	public PayrollServicesImpl(AssociateDAO associateDAO) {
		super();
		this.associateDAO = associateDAO;
	}

	@Override
	public int acceptAssociateDetails(String firstName, String lastName, int yearlyInvestmentUnder80C,
			String department, String designation, String pancard, String emailId, int basicSalary, int epf,
			int companyPf, int accountNumber, String bankName, String ifscCode) {
		Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, 
				new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber,bankName, ifscCode));
		associate=associateDAO.save(associate);
		return associate.getAssociateID();
	}

	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {


		Associate associate=this.getAssociateDetails(associateId);
		associate.getSalary().setHra(associate.getSalary().getBasicSalary()*40/100);
		associate.getSalary().setConveyanceAllowance(associate.getSalary().getBasicSalary()*30/100);
		associate.getSalary().setPersonalAllowance(associate.getSalary().getBasicSalary()*20/100);
		associate.getSalary().setOtherAllowance(associate.getSalary().getBasicSalary()*20/100);
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getEpf()+
				associate.getSalary().getCompanyPf()+associate.getSalary().getHra()+associate.getSalary().getConveyanceAllowance()+
				associate.getSalary().getPersonalAllowance()+associate.getSalary().getOtherAllowance());

		int annualTax=0;
		int annualSalary=associate.getSalary().getGrossSalary()*12;
		int tax=annualSalary-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()*12-associate.getSalary().getCompanyPf()*12;
		int monthlyTax=annualTax/12;
		
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-monthlyTax);
		associateDAO.update(associate);
		return associate.getSalary().getNetSalary();
	}
	
	public int checkYearlyInvestmentUnder80C(int associateId,int annualGrossSalary) throws AssociateDetailsNotFoundException{
		Associate associate=this.getAssociateDetails(associateId);
		if(associate.getYearlyInvestmentUnder80C()<=180000)
			annualGrossSalary=annualGrossSalary-associate.getYearlyInvestmentUnder80C();
		else
			annualGrossSalary=annualGrossSalary+associate.getYearlyInvestmentUnder80C()-180000;
		
		return annualGrossSalary;
	}
	public int taxCalculator(int associateId,int annualGrossSalary) throws AssociateDetailsNotFoundException{
		if(annualGrossSalary>0 && annualGrossSalary<=25000)
			return 0;
		else if(annualGrossSalary>250000 && annualGrossSalary<=500000) {
			this.checkYearlyInvestmentUnder80C(associateId,annualGrossSalary);
			return (annualGrossSalary-250000)*10/100;
		}
			
		else if(annualGrossSalary>500000 && annualGrossSalary<=1000000) {
			this.checkYearlyInvestmentUnder80C(associateId,annualGrossSalary);
			return (annualGrossSalary-500000)*20/100+(annualGrossSalary-250000)*10/100;
		}
			
		else {
			this.checkYearlyInvestmentUnder80C(associateId,annualGrossSalary);
			return (annualGrossSalary-1000000)*30/100+(annualGrossSalary-500000)*20/100+(annualGrossSalary-250000)*10/100;
		}
		
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=associateDAO.findOne(associateId);
		if(associate==null)throw new AssociateDetailsNotFoundException("Associate details not found for associateId"+associateId);
		return associate;
	}

	@Override
	public List<Associate> getAllAssociatesDetails() {

		return associateDAO.findAll();
	}

}
