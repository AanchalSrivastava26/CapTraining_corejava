
public class EnhancedLoop {

	public static void main(String[] args) {
int a[]= {2,34,1,0};
int k=1;
for (int i : a) {
	if(a[i]==k)
		System.out.println("element found at "+i);
	break;
}

	}

}
