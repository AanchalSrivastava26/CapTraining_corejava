
public class Sample {
	static int num;
	int num1,num2;

	{	num1=10;
	num2=20;
	}

	public 	Sample() {
		num1++;
		num2++;
	
	
	}
	public Sample(int num1, int num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
		num1++;
		num2++;
		num++;
	}



	public void display() {
		System.out.println(num);
		System.out.println(num1+" "+num2);


	}

	public static void main(String[] args) {
		Sample s=new Sample();
		Sample s1=new Sample(3,4);
		Sample s2=new Sample(5,6);
		s.display();	
		s1.display();
		s2.display();

	}

}
